import CharacterGallery from '../components/CharacterGallery'
import { render } from '@testing-library/react';

it('CharacterGallery Component Renders Without Error', () => {
    render(<CharacterGallery />);
});